import { GET_EMAIL_VALIDATE, GET_RESEND_URL,GET_LOGINURL_TWILIO, GET_TWILIO,} from '../constants/constant';
import axios from 'axios';

export const forgotpasswordData = (data,token,id) => (dispatch) => {
  const header = {
    'Content-type':'application/json',
    'Authorization':`Bearer ${token}`,
    'code':`${id}`
   }
 
axios.get(GET_LOGINURL_TWILIO,data,{headers:header}).then(res=>{
 
     dispatch({
      type: GET_TWILIO,
      data: res.data && res.data.Resources && res.data.Resources[0]
        });
      
    
})
.catch(error => {
    // dispatch({
    //     type:GET_USER,
    //     data: 401
    // });
    // Alert.error(error,ALERT_CONFIG);
    // context.history.push('/');
})
};