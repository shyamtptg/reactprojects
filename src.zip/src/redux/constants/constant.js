export const USER_TOKEN = "TOKEN_USER";
export const LOGIN_URL = "https://myinno.myglu.com/oxauth/restv1/token";
export const USER_SIGNUP = "USER_SIGNUP";
export const UPDATE_USER= "UPDATE_USER";
export const GET_VALIDATE="GET_VALIDATE";
export const GET_USER="GET_USER";
export const GET_EMAIL_VALIDATE="GET_EMAIL_VALIDATE";
export const GET_RESEND_VALIDATE="GET_RESEND_VALIDATE";
export const GET_EMAIL_URL="http://192.168.208.233:80/jemstepUser/user/emailOtpUser"
export const GET_RESEND_URL="http://mahesh.myglu.com/jemstepUser/user/emailOtpUser"
// export const GET_EMAIL_URL="https://myinno.myglu.com/identity/restv1/scim/v2/Users/"
// export const USER_ERROR="USER_ERROR";
export const UPDATE_USER_URL="http://192.168.208.233:80/jemstepUser/user/userUpdate"
export const GET_USERLOGIN_URL = "https://myinno.myglu.com/oxauth/restv1/token";

export const SIGNUP_URL = "http://mahesh.myglu.com/jemstepUser/user/createUser";
export const GETUSERS_URL = "http://192.168.208.233/jemstepUser/user/retrievUser";

