import React from 'react';



// import Alert from 'react-s-alert';
// import 'react-s-alert/dist/s-alert-default.css';
// import 'react-s-alert/dist/s-alert-css-effects/bouncyflip.css';
// import Login from './components/Login';
import Home from './components/Home/Home';



const App = () => (
  <div className="App">
    <Home/>
    
  </div>
);




export default App;
