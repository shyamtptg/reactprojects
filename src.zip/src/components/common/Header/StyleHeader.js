
const logo={
  marginTop:'23px',
  marginLeft:'115px',
  marginBottom:'20px',
  width: '195.06px'
}
export const Header={
  logo:logo
}