const PageHeader={
  signUpRoute:'Now take the next step to financial freedom',
  loginRoute:'Welcome back to Bank',
  validateEmailRoute:'You have successfully signed up with NextGenBank',
  validateEmailRouteContent1:'A confirmation email with security code has been sent to j@gmail',
  validateEmailRouteContent2:'Please enter the security below within 24 hours to verify your email',
  sucessvalidateRoute: 'Congratulations!',
  twofactorAuthenticationRoute:'Two Factor authentication',
  twofactorContent1:'Please select your country code and enter phone number we will send an SMS with security code to verify',
  twofactorContent2:'Your phone number and enable two factor authentication',
  
}
export const PageHeaderRoutes={
  PageHeader:PageHeader
}