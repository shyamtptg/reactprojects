
// import variables from '../../../css/variables.scss';

//  const footerMain= {
//     backgroundColor: `${variables.azure}`,
//     padding: "30px 100px"+'!important',
//     marginTop: "60px"
//     }
//   console.log(footerMain);
//   const footerList ={ borderRight: `1px solid ${variables.whitecolor}` }
//   const footerListUl= { paddingLeft:"0px", margin:"0px", padding:" 5px 0px" }
//   const footerListUlLi= { listStyleType: "none", display:"inline", paddingRight:"40px" }
//   const footerListUlLiA= { color: variables.whitecolor }
 
//  const footerMiddle = {
//       borderRight: `1px solid ${variables.whitecolor}`
//   }
//   const footerMiddlePara={ 
//       color: variables.regentblue,
//       fontSize: "16px" 
//     }
//   const footerRightPar= {
//       textAlign: "center",
//     color:variables.regentblue,
//     fontSize: "16px",
//     paddingTop: "25px"
//   }
//   const footerRightParaLink= {
//   color: variables.whitecolor,
//     fontSize: "18px",
//     paddingLeft: "10px"
//     }
//     const footerBottomPara= {
//     textAlign: "left",
//     color: variables.regentblue,
//     fontSize: "16px",
//     marginBottom: "0px"
//     }
// export const Footer={
//     footerMain:footerMain,
//     footerMiddle:footerMiddle,
//     footerMiddlePara:footerMiddlePara,
//     footerRightPar:footerRightPar,
//     footerRightParaLink:footerRightParaLink,
//     footerBottomPara:footerBottomPara,
//     footerList:footerList,
//     footerListUl:footerListUl,
//     footerListUlLi:footerListUlLi,
//     footerListUlLiA:footerListUlLiA
// }