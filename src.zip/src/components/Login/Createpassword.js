import React, { Component } from 'react';
import validate from 'validate.js';
import { Link } from 'react-router-dom';
import { styles } from '../common/style';
import './login.scss';
class Createnewpassword extends Component {
  render() {
    return (

      <div class="container">
        <div class="row form-body">
          <div class='two-fact-card col-md-5'>
            <div class='Success'>
              <div class='card'>
                <div class='card-header two-fact-auth1'>
                  Create a new password
            </div>
                <div class='card-block'>
                  <form>
                    <div class='form-group col-12'>
                      <div class='row'>
                        <div class="col-12">
                          <label>Password</label>
                        </div>
                      </div>
                      <input type='password' class="form-control" id='email' name='email' placeholder="Password"
                      />
                    </div>

                    <div class='form-group col-12'>
                      <button type='button' class="btn-class"><span >CREATE PASSWORD</span></button>
                    </div>


                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default Createnewpassword;