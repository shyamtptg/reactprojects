import React, { Component } from 'react';
import validate from 'validate.js';
import { Link } from 'react-router-dom';
import { styles } from '../common/style';
import './login.scss';
class ForgotPasswordcheckmail extends Component {



  render() {
    return (
      <div class='container'>
        <div class='row form-body-forgot'>
          <div class='two-fact-card col-md-12'>
            <div class='Success'>
              <div class='card'>
                <div class='card-header two-fact-auth1'>
                  Enter security code
                    </div>
                <div class='card-block'>
                  <form>
                    <div class='form-group col-12'>
                      <div class='row'>
                        <div class='col-12'>
                          <label>Security code</label>
                          <a href=''>Resend code</a>
                        </div>
                      </div>
                      <input type='email' class='form-control' id='email' name='email' placeholder='123456'
                      />
                    </div>

                    <div class='form-group col-12'>
                      <button type='button' class='btn-class'><span >CONTINUE</span></button>
                    </div>

                    <div class='form-group col-12'>
                      <p class='bottom'>Code was sent to wrong email address</p>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


    )
  }
}
export default ForgotPasswordcheckmail;




